﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Message_Board
{
    public partial class Form1 : Form
    {
        MySqlConnection con;
        MySqlCommand com;
        MySqlDataReader dr;
        messageboard_DB db = new messageboard_DB();

        public Form1()
        {
            InitializeComponent();
            con = new MySqlConnection(db.ConnectionString());
        }

        private void GetIDNumber()
        {
          
            con.Open();
            com = new MySqlCommand("SELECT COUNT(*) FROM `add_client_tb`", con);
            string ID = com.ExecuteScalar().ToString();
            txtID.Text = "CMB-00" + ID.ToString();
            
            con.Close();
        }

        private void AddUser()
        {
            con.Open();
            com = new MySqlCommand("INSERT INTO `add_client_tb`(`user_id`, `full_name`, `address`, `phone_number`, `amount_of_credit`) VALUES (@user_id, @full_name, @address, @phone_number, @amount_of_credit)", con);
            com.Parameters.AddWithValue("@user_id", txtID.Text);
            com.Parameters.AddWithValue("@full_name", txtName.Text);
            com.Parameters.AddWithValue("@address", txtAddress.Text);
            com.Parameters.AddWithValue("@phone_number", txtNumber.Text);
            com.Parameters.AddWithValue("@amount_of_credit", txtAmount.Text);
            com.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("User Registered Successfully");
            Clear();
        }

        public void Clear()
        {
            txtID.Text = "";
            txtName.Text = "";
            txtAddress.Text = "";
            txtNumber.Text = "";
            txtAmount.Text = "";

            GetIDNumber();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddUser();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GetIDNumber();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
