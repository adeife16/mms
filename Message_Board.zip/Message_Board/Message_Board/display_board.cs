﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Message_Board
{
    public partial class display_board : Form
    {
        MySqlConnection con;
        MySqlCommand com;
        MySqlDataReader dr;
        messageboard_DB db = new messageboard_DB();


        string client_Name = "";
        string client_Message = "";
        string days_to_display = "";
        string cost_of_messaage = "";
        string product_Name = "";




        public display_board()
        {
            InitializeComponent();
            con = new MySqlConnection(db.ConnectionString());
           timer1.Start();

    }


        private void DisplayMessage()
        {
            try
            {

                con.Open();
                com = new MySqlCommand("SELECT `fullname`,  `message_to_display`,  `cost_of_message`, `no_of_day_to_display` FROM `client_message`", con);
                dr = com.ExecuteReader();
                           
           
                dr.Close();
                con.Close();

                lblClientName.Text = client_Name;
                lblClientMessage.Text = client_Message;
                lblCostMessage.Text = cost_of_messaage;
                lblNoDays.Text = days_to_display;


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                con.Close();
            }

        }
        private void display_board_Load(object sender, EventArgs e)
        {
            DisplayMessage();         
        }


        private void AnimateClientName()
        {
            if (lblClientName.Text == string.Empty)

            {

            }
            else
            {
    

            }

        }
      

        private  void AnimateClientMessage()
        {
            if (lblClientMessage.Text == string.Empty)

            {

            }
            else
            {

                string s1a = lblClientMessage.Text;
                string s2a = s1a.Substring(0, 1);
                string s3a = s1a.Substring(1, s1a.Length - 1);
                string s4a = s3a + s2a;
                lblClientMessage.Text = s4a;
            }


        }
        private void button1_Click(object sender, EventArgs e)
        {
        
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            AnimateClientName();
            AnimateClientMessage();

           
            //DateTime end_time = new DateTime(DateTime.Now.Year, DateTime.Now.Day, DateTime.Now.Month);
            lblDate.Text = DateTime.Now.ToString("yyyy-dd-MM");
            
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void lblClientMessage_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void GetClientProduct()
        {
            try
            {
                con.Open();
                com = new MySqlCommand("SELECT `product_name` FROM `product` WHERE user_id=@user_ID", con);
                com.Parameters.AddWithValue("@user_ID", textBox1.Text);
                dr = com.ExecuteReader();
                while (dr.Read())
                {

                    product_Name = Convert.ToString(dr["product_name"]);

                }
                dr.Close();
                con.Close();
                if(product_Name == "")
                {
                MessageBox.Show("User product not found");
                product_Name = "product not found";
                }
                label3.Text = product_Name;
            }
            catch (Exception ex)
            {
                con.Close();
            }
        }
        private void SelectClientMessage()
        {
            try
            {
                con.Open();
                com = new MySqlCommand("SELECT `fullname`, `message_to_display`,  `cost_of_message`, `no_of_day_to_display`, end_time FROM `client_message` WHERE user_ID=@user_ID", con);
                com.Parameters.AddWithValue("@user_ID", textBox1.Text);
                dr = com.ExecuteReader();
                while (dr.Read())
                {

                    client_Name = Convert.ToString(dr["fullname"]);
                    client_Message = Convert.ToString(dr["message_to_display"] + "    ");
                    cost_of_messaage = Convert.ToString(dr["cost_of_message"]);
                    days_to_display = Convert.ToString(dr["no_of_day_to_display"] + " days ");

                }
                dr.Close();
                con.Close();
                lblClientName.Text = client_Name;
                lblClientMessage.Text = client_Message;
                lblCostMessage.Text = cost_of_messaage;
                lblNoDays.Text = days_to_display;

            }
            catch (Exception ex)
            {

                MessageBox.Show("User doesn't exist");
                con.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
                lblClientName.Text = null;
                lblClientMessage.Text = null;
                lblCostMessage.Text = null;
                lblNoDays.Text = null;
            label3.Text = null;
            

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            GetClientProduct();
            SelectClientMessage();

           // textBox1.Clear();
           // textBox1.Focus();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {


        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void lblEvents_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
