﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Message_Board
{
    public partial class product : Form
    {
        MySqlConnection con;
        MySqlCommand com;
        MySqlDataReader dr;
        messageboard_DB db = new messageboard_DB();
        public product()
        {
            InitializeComponent();
            con = new MySqlConnection(db.ConnectionString());
        }


        private void AddProduct()
        {

            con.Open();
            com = new MySqlCommand("INSERT INTO `product`(`user_id`,`product_name`) VALUES (@user, @product_name)", con);
            com.Parameters.AddWithValue("@user", comboBox1.SelectedValue.ToString());
            com.Parameters.AddWithValue("@product_name", textBox1.Text);
            com.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("New Product has been Added");
        }
        private void product_Load(object sender, EventArgs e)
        {
            GetUserId();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddProduct();
        }

        private void GetUserId()
        {
            DataTable dt = new DataTable();
            con.Open();
           MySqlCommand com = new MySqlCommand("SELECT user_id, full_name FROM `add_client_tb`", con);
            dr = com.ExecuteReader();
            dt.Load(dr);

            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "user_id";
            comboBox1.DisplayMember = "full_name";
            con.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
