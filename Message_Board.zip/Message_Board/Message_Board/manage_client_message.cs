﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Message_Board
{
    public partial class manage_client_message : Form
    {
        MySqlConnection con;
        MySqlCommand com;
        MySqlDataReader dr;
        messageboard_DB db = new messageboard_DB();

        public manage_client_message()
        {
            InitializeComponent();
            con = new MySqlConnection(db.ConnectionString());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Search for Client using ID
        private void SearchClient()
        {
            
            try
            {

                con.Open();
                com = new MySqlCommand("SELECT `user_id`, `full_name`, `address`, `phone_number`, `amount_of_credit` FROM `add_client_tb` WHERE user_id=@user_id", con);
                com.Parameters.AddWithValue("@user_id", txtSearch.Text);
                dr = com.ExecuteReader();
                if (dr.Read())
                    MessageBox.Show("Client Record Found");
                {
                    txtName.Text = Convert.ToString(dr["full_name"]);
                    txtAddress.Text = Convert.ToString(dr["address"]);
                    txtNumber.Text = Convert.ToString(dr["phone_number"]);
                      txtAmount.Text = Convert.ToString(dr["amount_of_credit"]);
                    //  txtName.Text = Convert.ToString(dr["full_name"]);
                }
                dr.Close();
                con.Close();

            }
            catch (Exception ex)
            {

                dr.Close();
                con.Close();
                MessageBox.Show(ex.Message, "USER DOESN'T EXIST", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);
            }

        }
        #endregion

        private void SaveMessage()
        {
            TimeRange();

        }

        public void TimeRange()
        {
            string client_unit = txtAmount.Text;
            string cost_of_message = txtCost.Text;
            string No_of_days = numericUpDown1.Value.ToString();
            int sum = 0;

                DateTime end_time = new DateTime(DateTime.Now.Year, DateTime.Now.Day + 1, DateTime.Now.Month);
                DateTime start_time = new DateTime(DateTime.Now.Year, DateTime.Now.Day, DateTime.Now.Month);
                 
                if (Convert.ToInt32(client_unit) >0)
                {
                    //sum = 
                        

                    con.Open();
                    com = new MySqlCommand("INSERT INTO `client_message`(`user_ID`, `fullname`, `address`, `phone_number`, `amount_of_credit`, `no_of_day_to_display`, `cost_of_message`, `message_to_display`, `start_time`, `end_time`) VALUES (@user_ID, @fullname, @address, @phone_number, @amount_of_credit, @no_of_day_to_display, @cost_of_message, @message_to_display, @start_time, @end_time)", con);
                    com.Parameters.AddWithValue("@user_id", txtSearch.Text);
                    com.Parameters.AddWithValue("@fullname", txtName.Text);
                    com.Parameters.AddWithValue("@address", txtAddress.Text);
                    com.Parameters.AddWithValue("@phone_number", txtNumber.Text);
                    com.Parameters.AddWithValue("@amount_of_credit", Convert.ToInt32(client_unit)-Convert.ToInt32(cost_of_message));
                    com.Parameters.AddWithValue("@no_of_day_to_display", numericUpDown1.Value);
                    com.Parameters.AddWithValue("@cost_of_message", txtCost.Text);
                    com.Parameters.AddWithValue("@message_to_display", richTextBox.Text);
                    com.Parameters.AddWithValue("@start_time", start_time);
                    com.Parameters.AddWithValue("@end_time",end_time);

                    com.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Messaage Saved For Dispaly");
                    //Clear();
                    con.Close();

                    con.Open();
                    com = new MySqlCommand("UPDATE `add_client_tb` SET amount_of_credit =@amount_of_credit WHERE user_id =@user_id", con);
                    com.Parameters.AddWithValue("@user_id", txtSearch.Text);
                    com.Parameters.AddWithValue("@amount_of_credit", Convert.ToInt32(client_unit) - Convert.ToInt32(cost_of_message));
                    com.ExecuteNonQuery();
                    con.Close();

                    
                }
                else
                {
                    MessageBox.Show("Client Credit has Exhausted");
                }
                txtDaysToDisplay.Text = "START TIME >> "+ start_time.ToString();
                txtDaysToDisplay.Text = "END TIME >> " + end_time.ToString();


        }
        private void MessageDuration()
        {
            
        }
        private void manage_client_message_Load(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SearchClient();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            SaveMessage();
        }

        private void richTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
