﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Message_Board
{
    class messageboard_DB
    {
        public string ConnectionString()
        {
            string connection = "datasource=localhost; user=root; password=; Database=message_board_db";
            return connection;
        }
    }
}
