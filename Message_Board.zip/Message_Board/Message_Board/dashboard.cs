﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Message_Board
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 addUser = new Form1();
            addUser.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            add_message message = new add_message();
            message.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            manage_client_message client_Message = new manage_client_message();
            client_Message.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            product add_product = new product();
            add_product.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            product_event_info product_event = new product_event_info();
            product_event.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Exit Application?","CLICK "+"YES"+" TO CLOSE APPLICATION", MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)

            {
                Application.Exit();
            }
            else
            {
                return;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            display_board display_Board = new display_board();
            display_Board.Show();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
