﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Message_Board
{
    public partial class add_message : Form
    {
        MySqlConnection con;
        MySqlCommand com;
        MySqlDataReader dr;
        messageboard_DB db = new messageboard_DB();

        public add_message()
        {
            InitializeComponent();
            con = new MySqlConnection(db.ConnectionString());
        }

        private void AddNewMessage()
        {
            con.Open();
            com = new MySqlCommand("INSERT INTO `add_message`(`add_message`, `no_days`, `days_left`, `message_desc`) VALUES (@add_message, @no_days, @days_left, @message_desc)", con);
            com.Parameters.AddWithValue("@add_message", txtAddMessage.Text);
            com.Parameters.AddWithValue("@no_days", txtNoOfDays.Text);
            com.Parameters.AddWithValue("@days_left", txtDaysLeft.Text);
            com.Parameters.AddWithValue("@message_desc", richTextBox.Text);
            com.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Message has been Added");
        }
        private void add_message_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddNewMessage();
        }
    }
}
