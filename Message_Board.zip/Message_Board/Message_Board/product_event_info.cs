﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Message_Board
{
    public partial class product_event_info : Form
    {
        MySqlConnection con;
        MySqlCommand com;
        MySqlDataReader dr;
        messageboard_DB db = new messageboard_DB();

        public product_event_info()
        {
            InitializeComponent();
            con = new MySqlConnection(db.ConnectionString());
        }

        private void GetProduct()
        {
            con.Open();
            com = new MySqlCommand("SELECT * FROM `product`", con);
            dr = com.ExecuteReader();
            while (dr.Read())
            {
                comboBoxProduct.Text = dr["product_name"].ToString();
            }
            dr.Close();
            con.Close();
        }


        private void AddEvent()
        {
            con.Open();
            com = new MySqlCommand("INSERT INTO `product_event`(`product`, `message_display`, `local_event`, `staffs_requirement`) VALUES (@product, @message_display, @local_event, @staffs_requirement)", con);
            
            com.Parameters.AddWithValue("@product", comboBoxProduct.Text);
            com.Parameters.AddWithValue("@message_display", richTextBox.Text);
            com.Parameters.AddWithValue("@local_event", txtLocal.Text);
            com.Parameters.AddWithValue("@staffs_requirement", richTextBoxStaff.Text);
            com.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Product and Event set for display");
        }
        private void product_event_info_Load(object sender, EventArgs e)
        {
            GetProduct();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddEvent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
